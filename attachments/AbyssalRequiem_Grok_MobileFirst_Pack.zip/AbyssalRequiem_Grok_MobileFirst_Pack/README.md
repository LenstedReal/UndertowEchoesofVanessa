# Abyssal Requiem — Grok Mobile-First Plan Pack

## Grok'a yükleme
1. `AbyssalRequiem_Grok_MobileFirst_Pack.zip` dosyasını Grok'a yükle.
2. `GROK_MASTER_PLAN_TR.md` dosyasındaki promptu tek mesaj olarak yapıştır.
3. İlk turda yalnızca plan istemektedir; Grok'un hemen kod yazmasına izin verme.
4. Planı onayladıktan sonra yalnızca Faz A ve Act 1 dikey kesitiyle ilerle.

## Bu pakette
- `GROK_MASTER_PLAN_TR.md`: Grok için kapsamlı ana prompt.
- `SOURCE_ANALYSIS_TR.md`: orijinal Unity AI paketi, 4 Act ve görsellerin analiz özeti.
- `TECH_DECISION_TR.md`: motor ve dil seçimi.
- `original_unity_ai_pack.zip`: orijinal GDD, Unity promptları ve görseller.
- `references/`: Act 1, Act 2 ve Act 4 referans görselleri.

## Kısa teknoloji kararı
Kullanıcının mevcut Unity Editor kurulumu çalışmadığı için ilk mobil prototip: Godot 4.7.2 stable + GDScript + Mobile renderer. Unity'ye sonra geçiş otomatik değildir; hikâye, sanat varlıkları ve tasarım belgeleri taşınabilir, motor/renderer/physics/input kodları yeniden yazılır. Eğer kaynak kodunun doğrudan Unity'de kullanılma zorunluluğu sonradan baskın hale gelirse, proje başlamadan Unity + URP + C# kararı tekrar değerlendirilmelidir.
