# Mobil teknoloji kararı — Abyssal Requiem

## Öneri: Godot 4.7.2 stable + GDScript + Mobile renderer (Android-first)

Kullanıcının Unity kurulum/Editor paneli henüz çalışmadığı ve önce telefonda oynanabilir bir sürüm görmek istediği varsayımıyla en uygulanabilir ilk rota Godot'un Android destekli, kararlı 4.7.2 sürümü ve GDScript'tir. Godot 4.7.2, 18 Ağustos 2026 tarihinde yayımlanmış kararlı sürüm olarak resmi indirme arşivinde listeleniyor. GDScript, Android Editor'da C#/.NET gerektirmeden çalışır; Godot Android Editor hâlâ erken erişim/deneysel olduğundan mobil arayüz ve dışa aktarma sınırlamaları proje başında test edilmelidir.

- Motor: Godot 4.7.2 stable (beta/dev değil).
- Birincil dil: GDScript; mümkün olan yerlerde tipli değişkenler ve tipli fonksiyonlar kullan.
- Renderer: Android için Mobile renderer. Godot Android Editor dokümanı, Forward+ renderer'ı Android Editor ortamında performans sorunları nedeniyle önermiyor.
- Hedef: Android ARM64, yatay ekran, dokunmatik FPS kontrolü.
- Android paket derlemesi: telefondaki editörün APK export yapabildiğini varsayma. Önce export yolunu sınama; olmazsa GitHub Actions veya masaüstü build makinesiyle export et.
- Harici kütüphane: ilk prototipte zorunlu plugin yok; yerleşik ses, fizik, UI ve dosya kayıt API'leri yeterli olsun.
- İlk performans hedefi: desteklenen orta sınıf Android cihazda kararlı 30 FPS; güçlü cihazlarda 60 FPS seçenekli. Bu ölçümler gerçek cihazda doğrulanmalı; FPS sözü yalnızca tasarım hedefidir.

## Önemli bedel: ileride Unity'ye geçiş

Godot/GDScript dosyaları Unity C# dosyaları olarak otomatik kullanılamaz. Hikâye, GDD, görsel/işitsel dosyalar, seviye planı, bulmaca verileri ve kabul testleri taşınabilir; oyuncu controller, fizik, shader, UI, render ve platform entegrasyonu yeniden yazılır. “Daha sonra Unity’ye geçiş” kesin ise, oyunun sistemlerini motor bağımsız GDD ve veri formatlarıyla tasarla ve ilk günden taşınabilir içerik kuralları kullan.

## Alternatif rota: aynı projeyi Unity ile devam ettirmek

Eğer asıl öncelik kodu ve oynanışı ileride Unity projesinde korumaksa doğru tercih Unity C# + URP'dir; HDRP değil. Ama Unity Editor/Android Build Support ve Android SDK ortamı olmadan yalnızca C# dosyası üretmek oynanabilir APK'yı garanti etmez. HDRP ve URP arasında render pipeline düzeyinde doğrudan uyumluluk yoktur; resmi Unity belgeleri taşımada shader, materyal, ışık ve post-process parçalarının yeniden ele alınması gerektiğini belirtiyor.

## Bu oyun için neden Kotlin değil?

Kotlin, Android uygulama kabuğu, dosya/ayar ekranı ve native Android servisleri için güçlüdür; ancak bu proje birinci şahıs 3D ortam, gerçek zamanlı kamera, 3D ses, ışık/fog, fizik bulmacaları ve seviye motoru isteyen bir oyundur. Kotlin tek başına Unity/Godot benzeri bir 3D motorun yerine geçmez. Oyunun ana dili olarak GDScript seçilmesi motorla beraber karar verilmesinden kaynaklanır; sadece “mobil dil” seçerek oyun motoru ihtiyacı ortadan kalkmaz.
