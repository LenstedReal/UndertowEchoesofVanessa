# Abyssal Requiem: Echoes of Vanessa — Kaynak ve Referans Analizi

## 1. Kaynak paketin içeriği

- `GDD.md`: 4 Act'lik birinci şahıs psikolojik korku / hayatta kalma / çevresel bulmaca tasarımı. Süre hedefi 3–4 saat.
- `prompts/01_Sanity_Sistemi_PLAN_modu.md`: 0–100 gizli Sanity modeli, Stable/Uneasy/Disturbed/Breaking kademeleri, FOV/post-process/çevre bozulması, `ISanityProvider`/`ISanityModifier`, ScriptableObject ayarları, debug paneli ve aşamalı uygulama planı.
- `prompts/02_HDRP_Volume_Listesi_ASK_modu.md`: Act 1 için Unity HDRP görsel ayarları (sis, gökyüzü, ışık, volume, gölge, post-processing ve kalite profilleri).
- `prompts/03_Listeyi_Uygula_AGENT_modu.md`: HDRP Volume Profile assetleri ve aktif sahne konfigürasyonunun oluşturulması talimatı.
- `gorseller/act1_cursed_galleon.jpg`: Lanetli kalyon / fener ve yoğun sis görseli.
- `gorseller/act2_ship_graveyard.jpg`: Gemi mezarlığı / ay ışığı ve fırtınalı okyanus görseli.
- `gorseller/act4_sunken_temple.jpg`: Batık tapınak / turkuaz biyolüminesans ve dev canlı silueti.
- `gamename.html`: `Undertow: Echoes of Vanessa` başlığını içeriyor; GDD'nin ana adı ise `Abyssal Requiem: Echoes of Vanessa`. Bir isim seçilip her yerde tutarlı kullanılmalı.

## 2. Görsel okuma

### Act 1 — The Cursed Galleon

Birinci şahıs kadrajında sağ ön planda sıcak, kirli amber ışık saçan eski el feneri; alt bölümde ıslak, çatlak tahta güverte; orta/arka planda yoğun gri-mavi sis içine kaybolan direk, ipler ve korkuluklar. Ay ışığı soğuk ve yaygın, fener ise tek güçlü sıcak renk odağı. Korku, görünmeyen alanı dolduran sis ve oyuncunun taşıdığı küçük ışık havuzundan doğuyor.

### Act 2 — The Ship Graveyard

Kadro iki yanda üst üste binmiş çok büyük, çürümüş gemi enkazlarıyla çevrili. Merkezde dar bir deniz geçidi ay ve bulutların altındaki parlak noktaya yöneliyor. Su soğuk lacivert-gri; az sayıda turkuaz ışık su yüzeyinde görülüyor. Kompozisyon ölçek, yalnızlık ve kaçış rotasının belirsizliğini öne çıkarıyor.

### Act 4 — The Sunken Temple

Derin su altında devasa gotik/antik kalıntılar, yukarıdan aşağı süzülen mavi ışık huzmeleri ve turkuaz parıltılar. Sol alt ön planda açık, ışıklı sandık; arkada dev bir deniz canlısı/whale silueti. Sandık, bölümün ilk okunabilir etkileşim odağı; dev canlı ise doğrudan saldırı yerine ölçek ve belirsizlik yaratıyor.

### Act 3 — The Forsaken Port

Kaynak GDD bölümün metnini içeriyor ancak ayrı bir görsel referans yok. Liman görsel dili diğer bölümlerden türetilmeli: 18. yüzyıl korsan kasabası, diz hizasında su, durgun sokaklar, ay ışığı, Vanessa'nın ayak izleri ve geçmiş günahları çağrıştıran çevresel izler. Act 3 kendi konsept sayfasıyla tamamlanmadan varlık üretimine başlanmamalı.

## 3. Güçlü tasarım çekirdeği

1. Korku jump-scare ve gore'a değil atmosfer, ses, bekleyiş ve oyuncunun güvenilmez algısına dayanıyor.
2. Fener gerçek bir kaynak yönetimi aracı: yağ sınırlı; alev rüzgâr/koşu ile etkilenebilir.
3. Sanity doğrudan HUD çubuğu olarak görünmez; oynanışın görsel ve işitsel davranışını etkiler.
4. Oyuncu bakmıyorken heykel, tablo ve çevre parçaları değişebilir; bu olaylar seyrek ve gözlemlenebilir olmalı, ekranın önünde rastgele teleport olmamalı.
5. Bulmacalar çevresel ve işitsel: müzik kutusu/ninni, ağırlık merkezi ve enkaz geçişleri.

## 4. Çözülmesi gereken çelişkiler / riskler

- GDD, Unity 6 + HDRP varsayıyor; HDRP ağırlıkla yüksek kaliteli masaüstü/konsol hedefidir ve URP/HDRP projeleri birbirleriyle doğrudan uyumlu değildir. Mobil hedef için HDRP Volume talimatları doğrudan uygulanamaz. Kaynak amaçlarını motor bağımsız olarak tut; seçilen mobil motorun sis/ışık/post-process karşılıklarını yeniden tasarla.
- “3–4 saatlik oyun” ilk teslimat için fazla büyük. Önce 10–15 dakikalık, baştan sona oynanabilir bir Act 1 dikey kesiti doğrula; diğer Act'leri sonra genişlet.
- Verilen üç görsel 3D model/texture/rig değildir; konsept art referansıdır. Gerçek 3D ortamlar, malzemeler, normal/roughness haritaları, el-feneri modeli, sesler ve animasyonlar ayrıca üretilmeli veya lisanslı assetlerle ikame edilmeli.
- Sanity promptundaki HDRP `Volume`, C# event, ScriptableObject ve HDRP API adları Godot'a birebir taşınamaz. Kavramları koru, API'leri seçilen motor için yeniden tasarla.
- Açık denize 6 saniye bakma, karanlıkta kalma ve rahatsız edici objeyi inceleme gibi tetikleyiciler açıklanmalı; oyuncu bunların neden olduğunu tahmin edebilmeli, fakat gizli Sanity sayısını görmemeli.
- Rastgele çevre bozulması, kamera FOV değişimi ve yüksek hareket bulanıklığı mobil oyuncularda rahatsızlık yaratabilir. Bunları seçeneklerden azaltma/kapama ve hareket hastalığına duyarlı mod gerekli.

## 5. Önerilen kanonik karar

- Oyun adı: **Abyssal Requiem: Echoes of Vanessa**. `Undertow: Echoes of Vanessa` alternatif başlık olarak notta tutulabilir ancak dosya, ikon, menü ve proje kimliğinde iki ad birden kullanılmamalı.
- Platform sırası: Android ilk, ardından daha fazla cihazda test; iOS ancak ayrı export/cihaz testi hazır olduğunda.
- İlk kilometre taşı: Act 1'in tek sahneli prototipi, 10–15 dakika hedef; bütün 4 Act'i bir kerede geliştirme yok.
