# Undertow: Echoes of Vanessa — Grok talimat paketi

Bu paket, mevcut düşük kaliteli demoyu tek başına nihai temel saymak yerine **3–4 saatlik PC/Steam psikolojik korku oyununu** baştan sona doğru aşamalarla üretmek için hazırlanmış ana talimatı içerir.

## Dosyalar
- `UNDERTOW_GROK_MASTER_PROMPT_TR.md` — biçimlendirilmiş ana prompt.
- `UNDERTOW_GROK_MASTER_PROMPT_TR.txt` — düz metin sürümü; Grok'a kolayca yapıştırmak için.

## Kullanım
1. Ana prompt dosyasını Grok'a yükle veya tamamını mesaja yapıştır.
2. Elindeki orijinal kaynak paketini (`GDD.md`, `README.md`, `gamename.html`, prompt dosyaları ve görseller) ayrıca ekle.
3. Grok'un erişebildiği gerçek oyun proje dosyalarını da yükle. Yalnızca ekran görüntüsü varsa Grok'un o proje dosyalarını inceleyemeyeceğini unutma.
4. İlk cevapta kaynak denetimi ve üretim planını bekle; ardından gerçek Unity proje dosyalarının aşamalar halinde üretilmesini iste. Unity Editor olmadan derleme/oynanış testi yapılmış sayılamaz.

**Doğru oyun adı:** `Undertow: Echoes of Vanessa` (`gamename.html` esas alınmıştır). Bu paket mobil araba savaşı projesinden ayrıdır.
