# Abyssal Requiem: Echoes of Vanessa — Unity AI Paketi

## İçindekiler
- `GDD.md` — Oyun tasarım özeti (4 Act, mekanikler, teknik hedefler, görsel referanslar)
- `prompts/01_Sanity_Sistemi_PLAN_modu.md` — Sanity, FOV, post-processing, EnvironmentDistortion
- `prompts/02_HDRP_Volume_Listesi_ASK_modu.md` — Act 1 HDRP Volume Profile listesi
- `prompts/03_Listeyi_Uygula_AGENT_modu.md` — Listeyi projeye uygulatma
- `gorseller/` — Act 1, 2 ve 4 için görsel referanslar

## Kullanım sırası
1. Projede `Assets/_Project/Docs/` klasörü aç; `GDD.md` ve `gorseller/` klasörünü oraya kopyala.
2. Unity AI Assistant'ı aç. Prompt 1'i **Plan** modunda gönder (gerekirse + ile GDD.md'yi ekle). Planı onayla, Agent uygular.
3. Prompt 2'yi **Ask** modunda gönder (+ ile `act1_cursed_galleon.jpg` eklemek hedef görünümü netleştirir).
4. Liste iyiyse Prompt 3'ü **Agent** modunda gönder.
5. Sistemler oturunca dişli > Refresh Project Overview. (Not: Project_Overview.md'ye elle yazılanlar yeniden üretimde silinir; bağlamı GDD.md'de tut.)

## Önerilen sonraki promptlar (her biri ayrı, Plan modunda)
Su (önce HDRP Water System + Water Master Stack) → Fener/yağ → Non-Euclid geçişler → Ses (spatial, FMOD-hazır arayüz) → Müzik kutusu bulmacası → Gemi enkazı fizik bulmacası.

## Not
Prompttaki sayılar başlangıç değerleridir; test ederek ayarla. Türkçe karakterlerde Assistant hata verirse İngilizce sürüm istenebilir.
