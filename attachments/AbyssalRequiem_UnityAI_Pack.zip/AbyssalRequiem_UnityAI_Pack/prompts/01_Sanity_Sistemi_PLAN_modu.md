Kıdemli bir Unity (C#) geliştiricisi ve HDRP teknik sanatçısı gibi çalış. "Abyssal Requiem: Echoes of Vanessa" adlı birinci şahıs psikolojik korku oyununun akıl sağlığı (Sanity) çekirdeğini kuruyoruz. Hazır bir "sanity bar" tutorial'ı değil, bu oyuna özel, yaratıcı ve sağlam bir sistem istiyorum. Açıklamaları Türkçe yaz; kod, isimler ve kod yorumları İngilizce olsun.

## Mevcut durum
- Unity 6 + HDRP projesi. Önce kendin tara: Unity/HDRP sürümü, Input System kullanımı, sahnedeki Main Camera, mevcut Volume'lar, varsa player controller. Bulduklarını 3 satırda özetle.
- Oyun: gemide başlayıp oyuncunun psikolojisi bozuldukça mekânları sürreal biçimde değişen bir FPS korku. Jump-scare ve gore YOK; korku atmosferden ve algı manipülasyonundan gelir.

## Hedef
HUD'da görünmeyen gizli bir Sanity değeri. Değer düştükçe: (1) kamera FOV'u dalgalansın, (2) HDRP post-processing bozulsun, (3) oyuncu bakmıyorken çevredeki objeler yer ve rotasyon değiştirsin.

## İstediğim davranışlar
1. Sanity modeli: 0–100, başlangıç 100. Tier'lar: Stable 100–70 / Uneasy 70–45 / Disturbed 45–20 / Breaking 20–0; ±3 histerezis (sınırda titreme olmasın). Değer ve tier değişimi C# event olarak yayınlansın; ses, heykel ve non-Euclid sistemleri sonradan abone olacak.
2. Etkenler (başlangıç değerleri; hepsi ScriptableObject'ten ayarlanabilir):
   - Sürekli: karanlıkta (fener sönük ya da karanlık-bölge trigger'ı içinde) −0,8/sn; denize 6 sn'den uzun bakınca (kameradan "Sea" layer'ındaki collider'a Raycast) −1,2/sn; fener yanıkken güvenli-bölge trigger'ında +1/sn.
   - Tek seferlik (ISanityModifier ile dışarıdan çağrılır): rahatsız edici objeyi incelemek −4, müzik kutusu çözmek +15. Etkileşim sistemi henüz yok; şimdilik debug panelinden tetikle.
   - Fener sistemi de henüz yok: durumunu ILanternState (IsLit) gibi küçük bir arayüzle oku; şimdilik debug panelinden açılıp kapanan bir implementasyon yaz.
3. FOV: Taban 70. Genlik tier'a göre 0° → 1° → 3° → 6°, frekans 0,15 → 0,7 Hz (aralarda AnimationCurve). Perlin noise + sinüs karışımı, SmoothDamp ile yumuşatılmış. Koşma gibi başka FOV değişimleriyle çakışmasın (additive offset).
4. Post-processing: Taban değerleri Start'ta Volume Profile'dan oku; AnimationCurve ile Sanity'e bağla: Vignette 0,25 → 0,55; Chromatic Aberration 0 → 0,35; Film Grain 0,1 → 0,5. Lens Distortion yalnızca tier aşağı değiştiğinde 1 sn'lik nabız yapsın (|maks| 0,3). Sahnede "LowSanity" adlı bir Volume varsa weight'ini de Sanity eğrisine bağla (yoksa atla).
5. EnvironmentDistortion: Uneasy'den itibaren, DistortableObject (MonoBehaviour) taşıyan objeler oyuncu bakmıyorken değişsin.
   - "Bakmıyor" = Vector3.Dot(camera.forward, hedefe yön) < cos(yatay yarı-FOV + 15°) (Camera.VerticalToHorizontalFieldOfView) VEYA kameradan objeye Linecast bir engele çarpıyor (objenin kendi collider'ı hariç). 2 m'den yakın ve 25 m'den uzak objelere dokunma.
   - Uneasy: ≤5 cm / ≤5° mikro kayma. Disturbed: heykel ve tablolar her seferinde ≤20° yaw ile oyuncuya döner, mobilya ≤35 cm kayar. Breaking: obje kaybolup (SetActive) opsiyonel alternatif noktada belirir.
   - Global en fazla 1 değişiklik / 4–8 sn; obje başına 30 sn cooldown. Sanity yükselip 10 sn sabit kalırsa objeler, yine bakılmıyorken, eski yerine döner.

## Teknik gereksinimler
- SOLID ama abartmadan: ISanityProvider (salt okunur) ve ISanityModifier (Drain/Restore) + SanitySettings ScriptableObject. Efektler SanityManager'a değil ISanityProvider'a bağlansın.
- Zorunlu dosyalar: SanityManager.cs ve EnvironmentDistortion.cs. Gerekirse yardımcı ekle (SanityTier, SanitySettings, SanityFovEffect, SanityPostProcessEffect, DistortableObject).
- Volume'da volume.profile (runtime instance) kullan, sharedProfile'a asla yazma. Override'ları TryGet ile başta bir kez cache'le (UnityEngine.Rendering.HighDefinition).
- Update'te GC alloc sıfır; FindObjectOfType/GetComponent yok; Camera ve Transform cache'li; kare başına en fazla 8 distortion adayı (round-robin). ProfilerMarker ekle; hedef: sistem toplamı ≤0,2 ms/kare.
- Assembly Definition kullanırsan HDRP, Core ve Input System referanslarını ekle. Kullandığın her API'nin kurulu sürümde var olduğundan emin ol; emin değilsen kullanma ve belirt.

## Teslimat
- Plan en fazla 8 adım ve 3 test edilebilir aşama olsun: (A) SanityManager + ayar asset'i + debug paneli, (B) FOV + post-processing, (C) EnvironmentDistortion. Netleştirme sorusu en fazla 3; gerisi için varsayımını planda yaz. Onayımı bekle.
- Dosyalar Assets/_Project/Scripts/Sanity/ altında tam ve eksiksiz olsun: "buraya kod gelecek", TODO ya da yarım metot YOK. Derleme hatası bırakma; her aşamadan sonra Console'u kontrol et.
- Aktif sahneye test düzeni kur: SanityManager, Volume bağlantısı, 6 örnek DistortableObject. Yalnızca Editor/Development Build'de çalışan, F1 ile açılan küçük bir debug paneli ekle (Sanity'i elle artır/azalt, tier'ı göster, fener ve tek seferlik etkenleri tetikle).
- Sonda kısa README (Assets/_Project/Docs/Sanity_README.md): kurulum, Inspector ayarları, 5 maddelik hızlı test listesi, bilinen sınırlar.
