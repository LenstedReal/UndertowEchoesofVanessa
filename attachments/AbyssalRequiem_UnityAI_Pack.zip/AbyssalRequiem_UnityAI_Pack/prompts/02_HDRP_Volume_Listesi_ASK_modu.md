Kıdemli bir HDRP teknik sanatçısı gibi çalış. "Abyssal Requiem" (birinci şahıs psikolojik korku) için Act 1 — "The Cursed Galleon" görünümünü HDRP Volume Profile ile kuracağız. Bu mesajda yalnızca yazılı bir liste istiyorum; projede hiçbir şeyi değiştirme. Açıklamaları Türkçe yaz.

## Mevcut durum
- Unity 6 + HDRP. Önce aktif sahneyi ve HDRP Asset'i oku: Directional Light, mevcut Volume'lar ve Lighting > Volumetrics / Contact Shadows / SSAO / SSR gibi özelliklerin HDRP Asset'te açık olup olmadığı. Kapalı olanları listele.
- Sahne: okyanusun ortasında, yoğun sisin içinde hareketsiz duran devasa korsan gemisi; dar, klostrofobik koridorlar. Işık yalnızca ay, fener ve meşale.

## Hedef görünüm
- Soğuk, yeşilimsi gri-mavi palet. Fener ve meşale tek sıcak vurgu. Siyahlar ezilmesin (siluetler okunsun) ama karanlık tekinsiz hissettirsin.
- Sis boğucu ve yakın: yaklaşık 35 m ötesi okunmasın. Gölgeler kapkaranlık değil, yumuşak ve "ray-traced hissi" veren türden olsun (Contact Shadows açık).
- Çıpa renkler (rafine edebilirsin): sis #4E5D62, gölge tonu #0B141A, ay ışığı #86A0C8, fener ≈2200 K #FF9227, halüsinasyon vurgusu #6FA38A.
- Ekli referans görsel varsa (act1_cursed_galleon.jpg) sis yoğunluğu, ay hâlesi ve fener sıcaklığı için ona yaklaş.

## İstediğim liste
Her satır: Override (Inspector'daki birebir ad) > Parametre = Değer (renkler #HEX) — tek cümle gerekçe.
1. Visual Environment ve gökyüzü (Physically Based, HDRI ya da Gradient: hangisi, neden).
2. Fog: volumetric fog açık; Fog Attenuation Distance, Base/Maximum Height (yükseklik sisi), albedo, anisotropy, kalite.
3. Local Volumetric Fog: koridor ve ambar için 2'şer örnek (boyut, density, renk). Volumetric Clouds: gerekli mi? Gerekliyse Local Clouds modunda değerler; değilse nedeni.
4. Exposure (mod ve değer), Tonemapping (ACES), Bloom, Color Adjustments, White Balance, Shadows Midtones Highlights. Taban değerler: Vignette 0,25, Film Grain 0,1, Chromatic Aberration 0, Lens Distortion 0 (Sanity kodu bunlardan başlayacak).
5. Işıklar HDRP fiziksel birimleriyle ve Exposure ile uyumlu: ay Directional Light (lux, renk), fener (lumen/candela, range, gölge), meşale.
6. Gölgeler: Contact Shadows, Shadows override (max distance, cascade), ışık gölge filtresi/yumuşaklığı.
7. SSAO, SSR (ıslak güverte), SSGI (opsiyonel; maliyetini yaz), Indirect Lighting Controller.
8. "LowSanity" Volume (global, yüksek priority, weight'i Sanity'e bağlı): Vignette, Film Grain, Chromatic Aberration ve Lens Distortion DIŞINDAKİ override'lar için sayılar (doygunluk, Exposure, sis yoğunluğu, hastalıklı yeşil ton).
9. Performans: pahalı ayarlar için LOW / MEDIUM / HIGH karşılıkları (orta-üst GPU, 1080p, 60 FPS).

## Biçim
- Tablo değil, kısa listeler.
- En sonda "Act 2 / 3 / 4'te yalnızca değişecek değerler" için kısa fark listesi.
- Emin olmadığın bir parametre adını uydurma; "Inspector'da şu bölümde ara" de.
