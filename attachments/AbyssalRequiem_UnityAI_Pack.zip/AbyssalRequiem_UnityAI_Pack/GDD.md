# Abyssal Requiem: Echoes of Vanessa — GDD Özeti

**Tür:** Birinci şahıs psikolojik korku, hayatta kalma ve bulmaca. **Motor:** Unity 6 + HDRP. **Süre:** 3–4 saat.

## Tasarım sütunları
- Jump-scare ve gore YOK. Korku atmosferden ve algı manipülasyonundan gelir.
- Gizli Sanity değeri düştükçe dünya oyuncuya karşı döner.
- Işık = kaynak: antika fener, yağı biter, rüzgârda/koşarken sönebilir.
- Bulmacalar çevresel: fizik tabanlı (ağırlık merkezi) ve ses tabanlı (Vanessa'nın ninnisi, müzik kutuları).

## Hikâye yapısı (4 Act)
### Act 1 — The Cursed Galleon (Lanetli Kalyon)
Okyanusun ortasında, yoğun sis (doldrums) içinde hareketsiz devasa korsan gemisi. Vanessa'nın kayboluşu fark edilir, mekanikler tanıtılır. Dar, klostrofobik koridorlar.
![Act 1](gorseller/act1_cursed_galleon.jpg)

### Act 2 — The Ship Graveyard (Gemi Mezarlığı)
Gemi, yüzyıllardır kayıp devasa gemilerin iç içe geçtiği labirentimsi bir okyanus çöplüğüne çarpar. Çürümüş kalyonlar, yosun tutmuş iskeletler, sallanan direkler arasında platform ve keşif bulmacaları.
![Act 2](gorseller/act2_ship_graveyard.jpg)

### Act 3 — The Forsaken Port (Terk Edilmiş Liman)
Sisten aniden beliren, zamanın durduğu 18. yüzyıl mimarisinde lanetli korsan kasabası. Sokaklarda diz boyu su, her yerde Vanessa'nın ayak izleri; oyuncunun geçmiş günahlarını yüzüne vuran halüsinasyonlar. *(Görsel referans henüz yok.)*

### Act 4 — The Sunken Temple (Batık Tapınak)
Suyun çekilmesi veya sürreal bir düşüşle ulaşılan, okyanus dibinde antik, Lovecraftvari kalıntılar. Final yüzleşmesi burada.
![Act 4](gorseller/act4_sunken_temple.jpg)

## Çekirdek mekanikler
**Sanity ve halüsinasyon:** Karanlıkta kalmak, denize uzun bakmak, rahatsız edici objeleri incelemek Sanity'i düşürür. Düştükçe:
- Non-Euclid geometri (kapıdan aynı odaya çıkma, arkana dönünce uzayan koridor)
- Fısıltı, tahta gıcırtısı, ağlayan çocuk sesi artışı (3D spatial audio, FMOD/Wwise'a geçişe hazır arayüz)
- Heykel/tabloların oyuncuya dönmesi veya değişmesi

**Işık ve kaynak:** Antika fener, yağ bulma motivasyonu oyuncuyu karanlık köşelere iter.

## Teknik hedefler (HDRP)
- Su: HDRP Water System tabanlı; derinlik tabanlı renk emilimi, su altı post-processing, köpük, gerekirse Water Master Stack ile özelleştirme.
- Atmosfer: Fog override (volumetric + yükseklik sisi), Local Volumetric Fog, gerekirse Volumetric Clouds (Local Clouds modu). Işık: yalnızca ay, fener, meşale.
- Gölge: yumuşak, Contact Shadows açık, "ray-traced hissi".
- Post: ACES, hafif Film Grain, duruma bağlı Lens Distortion, kaliteli Bloom.
- Performans hedefi: orta-üst GPU, 1080p, 60 FPS (LOW/MEDIUM/HIGH profilleri).

## Görsel palet çıpaları (Act 1)
Sis #4E5D62 · gölge tonu #0B141A · ay ışığı #86A0C8 · fener ≈2200 K #FF9227 · halüsinasyon vurgusu #6FA38A
